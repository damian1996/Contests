g++ -std=c++14 -g $1.cpp -o ex
./ex < test.in
